<?php
function bpl_draw_calendar($month, $year, $post_id=''){
	$today = date('j');
	$current_month = date('m');
	$current_year = date('Y');
	$current_date_int = strtotime($current_year.'-'.$current_month.'-'.$today);
	$post_availability = get_post_meta($post_id, 'dates_available', true) ? : array();
	$listed_users = get_post_meta($post_id, 'listed_users', true) ? : array();
	$current_user_id = get_current_user_id();


foreach ($listed_users as $key => $value) {
			if ($value['date_listed'] == '04-24-2020') {
				echo $value['user_name'] . '<br>';
			}
		}
	// Get available dates
	$available_dates = array();
	foreach ($post_availability as $key => $value) {
		$available_dates[] = $value['date_available'];
	}
	// Explode available dates
	$avail_date_explode = array(); 
	foreach ($available_dates as $key ) {
		$avail_date_explode[] = explode('-', $key);
	}
	// Make available dates integer
	$avail_date_int = array();
	foreach ($avail_date_explode as $key => $value ) {
		$avail_date_int[] = strtotime($value[2] . '-' . $value[0] . '-' . $value[1]);

	}
	// Take dates before current date for removal
	$remove_avail_dates = array();
	$rad_array = array();
	foreach ($avail_date_int as $key ) {
		if ($key < $current_date_int):
			$remove_avail_dates[] = $key;
			$rad_array[] = date("m-j-Y", $key);
		endif;

	}

	$bpl_num_users = get_option('bpl_num_users') ? : 10;
	$bpl_user_book_can = get_option('bpl_user_book_can') ? : 'subscriber';
	$bubc_array = explode(',', $bpl_user_book_can);

	// Get dates with listed users
	$wlisted_dates = array();
	if (is_user_logged_in()) :
		$current_user = wp_get_current_user();
		$cu_roles = ( array ) $current_user->roles;
		$get_wlisted_dates = get_post_meta($post_id, 'listed_users', true) ? : array();
		foreach ($get_wlisted_dates as $key => $value) {
			if ($value['user_id'] == $current_user_id || in_array('administrator', $cu_roles)) {
					$wlisted_dates[] = $value['date_listed'];
			}
		}
		$user = ' visitor';
		// identifies current user role
		if (in_array('administrator', $cu_roles)) :
			$user = ' admin';
		else:
			foreach ($bubc_array as $key => $value) :
				if (in_array($value, $cu_roles)) :
					$user = ' customer';
				endif;
			endforeach;
		endif;
	else:
		$user = ' visitor';
	endif;
	$calendar = '<table class="calendar">';
	$headings = array( 'Sun', 'Mon','Tue','Wed','Thu','Fri','Sat' );
	$calendar.= '<tr class="calendar-row"><td class="calendar-day-head">'.implode('</td><td class="calendar-day-head">',$headings).'</td></tr>';
	$running_day = date('w',mktime(0,0,0,$month,1,$year));
	$days_in_month = date('t',mktime(0,0,0,$month,1,$year));
	$days_in_this_week = 1;
	$day_counter = 0;
	$dates_array = array();
	$calendar.= '<tr class="calendar-row">';
	for($x = 0; $x < $running_day; $x++):
		$calendar.= '<td class="calendar-day-np"> </td>';
		$days_in_this_week++;
	endfor;

	for($list_day = 1; $list_day <= $days_in_month; $list_day++):
		// highlight today
		if ($list_day == $today && $month == $current_month && $year == $current_year) :
			$now = ' today';
		else:
			$now = '';
		endif;
		// Available/Booked/Closed Status
		$date_per_int = strtotime($year.'-'.$month.'-'.$list_day);
		$date_per = $month.'-'.$list_day.'-'.$year;
		if(in_array($date_per, $available_dates) && !in_array($date_per, $rad_array) && !in_array($date_per, $wlisted_dates)) :
			$availability = ' available';
			$availability_text = 'Available';
		elseif (in_array($date_per, $wlisted_dates)) :
			if ($date_per_int >= $current_date_int):
				$availability = ' booked';
				$availability_text = 'Available';


			else:
				$availability = ' closed booked';
				$availability_text = ' Closed';
			endif;
		else:
			$availability = ' unavailable';
			$availability_text = '';
		endif;
		// Past Present Future
		if ($date_per_int >= $current_date_int):
			$day_active = ' active';
		else:
			$day_active = ' inactive';
		endif;
		$user_listed = array();
		foreach ($listed_users as $key => $value) {
			if ($value['date_listed'] == $date_per) {
				$user_listed[] = $value['user_name'];
			}
		}
		$count_ul = count($user_listed);
		if ($bpl_num_users == $count_ul):
			$fully_booked = ' full';
			$availability_text = 'full';
		else:	
			$fully_booked = '';
		endif;
		$calendar.= '<td class="calendar-day'.$now.$user.$availability.$day_active.$fully_booked.'">';
			$calendar.= '<div class="day-number" data-date="'.$month.'-'.$list_day.'-'.$year.'">'.$list_day.'</div>';
			$calendar.= '<div class="day-status">'. $availability_text . '</div>';
		$calendar.= '</td>';
		if($running_day == 6):
			$calendar.= '</tr>';
			if(($day_counter+1) != $days_in_month):
				$calendar.= '<tr class="calendar-row">';
			endif;
			$running_day = -1;
			$days_in_this_week = 0;
		endif;
		$days_in_this_week++; $running_day++; $day_counter++;
	endfor;
	if($days_in_this_week < 8):
		for($x = 1; $x <= (8 - $days_in_this_week); $x++):
			$calendar.= '<td class="calendar-day-np"> </td>';
		endfor;
	endif;
	$calendar.= '</tr>';
	$calendar.= '</table>';
	return $calendar;
}
