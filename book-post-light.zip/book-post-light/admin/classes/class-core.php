<?php
class BOOK_POST_LIGHT_CLASS {
	function __construct(){
		add_action( 'wp_enqueue_scripts', array( $this, 'bpl_enqueue_scripts') );
		add_action( 'admin_enqueue_scripts', array( $this, 'bpl_enqueue_admin_scripts') );
		add_shortcode( 'bpl_display_calendar', array( $this, 'bpl_display_calendar' ) );
		add_action( 'wp_ajax_bpl_move_month', array( $this, 'bpl_move_month'));
		add_action('wp_ajax_nopriv_bpl_move_month', array( $this, 'bpl_move_month'));
		add_action( 'wp_ajax_bpl_set_availability', array( $this, 'bpl_set_availability'));
		add_action('wp_ajax_nopriv_bpl_set_availability', array( $this, 'bpl_set_availability'));
		add_action( 'wp_ajax_bpl_remove_avaibility', array( $this, 'bpl_remove_avaibility'));
		add_action('wp_ajax_nopriv_bpl_remove_avaibility', array( $this, 'bpl_remove_avaibility'));
		add_action( 'wp_ajax_bpl_get_listed', array( $this, 'bpl_get_listed'));
		add_action('wp_ajax_nopriv_bpl_get_listed', array( $this, 'bpl_get_listed'));
		add_action( 'wp_ajax_bpl_view_booking_admin', array( $this, 'bpl_view_booking_admin'));
		add_action('wp_ajax_nopriv_bpl_view_booking_admin', array( $this, 'bpl_view_booking_admin'));
		add_action( 'wp_ajax_bpl_cancel_booking', array( $this, 'bpl_cancel_booking'));
		add_action('wp_ajax_nopriv_bpl_cancel_booking', array( $this, 'bpl_cancel_booking'));
		add_action('admin_menu', array( $this ,'bpl_register_settings_page'));
		add_action( 'admin_init', array( $this, 'bpl_settings_group' ));
	}
	function bpl_enqueue_scripts() {
		// custom style
		wp_register_style( 'bpl-style', BOOK_POST_LIGHT_PLUGIN_URL . 'assets/css/style.css', BOOK_POST_LIGHT_VERSION);
		wp_enqueue_style( 'bpl-style' );
		// ajax
		wp_enqueue_script( 'jquery' );
		wp_localize_script( 'jquery', 'bpl_ajax_object',
				array( 'ajaxurl' => admin_url( 'admin-ajax.php' ) ) ); 
		// custom script
		wp_register_script( 'bpl-script', BOOK_POST_LIGHT_PLUGIN_URL . 'assets/js/bpl-script.js', array( 'jquery' ), BOOK_POST_LIGHT_VERSION, true );
		wp_enqueue_script( 'bpl-script' ); 
	}
	function bpl_enqueue_admin_scripts() {
			/*// admin scripts
		wp_enqueue_script( 'jmc-admin-script', BOOK_POST_LIGHT_PLUGIN_URL . 'admin/js/jmc-script.js', array( 'jquery' ), BOOK_POST_LIGHT_VERSION, true );
	*/
	}
	function bpl_display_calendar($atts) {
		ob_start();
            include( BOOK_POST_LIGHT_PLUGIN_PATH.'templates/bpl-calendar.php' );
		return ob_get_clean();
	}
	function bpl_move_month() {
		$show_month = $_REQUEST['show_month'] ? : '';
		$show_year = $_REQUEST['show_year'] ? : '';
		$month_action = $_REQUEST['month_action'] ? : '';
		$get_date = new DateTime($show_year . '-' . $show_month);
		$post_id = $_REQUEST['post_id'] ? : '';


		if ($month_action == 'prev-month') {
			$get_date->modify( 'last month' );
			$display_month = $get_date->format( 'm' );
			$display_year = $get_date->format( 'Y' );
			$show_date = $get_date->format('F Y');
		} elseif ($month_action == 'next-month') {
			$get_date->modify( 'next month' );
			$display_month = $get_date->format( 'm' );
			$display_year = $get_date->format( 'Y' );
			$show_date = $get_date->format('F Y');
		} else {
			$display_month = date('m');
			$display_year = date('Y');
			$show_date = date('F Y');
		}

		?>
		<div class='bpl-date-getter' >
			<div class="bpl-show-date" show-month="<?php echo $display_month; ?>" show-year="<?php echo $display_year; ?>"><?php echo $show_date; ?></div>
			<?php echo bpl_draw_calendar($display_month,$display_year,$post_id); ?>
		</div>
		<?php
		die();
	}
	function bpl_set_availability() {
		$made_available = $_REQUEST['get_date'] ? : '';
		$post_id = $_REQUEST['post_id'] ? : '';
		$current_availability = get_post_meta($post_id, 'dates_available', true) ? : array();
		$dates_available[] = array(
								'user_id' => get_current_user_id(),
								'post_id' => $post_id,
								'date_available' => $made_available

		);
		$merge_availability = array_merge($current_availability, $dates_available);
		update_post_meta($post_id, 'dates_available', $merge_availability);
		die();
	}
	function bpl_remove_avaibility() {
		$remove_availability = $_REQUEST['remove_availability'];
		$post_id = $_REQUEST['post_id'];
		$saved_availability = get_post_meta($post_id, 'dates_available', true) ? : array();

		foreach(array_keys($saved_availability) as $key) {
		if ($saved_availability[$key]['date_available'] == $remove_availability) {
				unset($saved_availability[$key]);
				update_post_meta($post_id, 'dates_available', $saved_availability);
			}
		}
		die();
	}
	function bpl_get_listed() {
		$current_user_id = get_current_user_id() ? : '';
		$user_data = get_userdata($current_user_id);
		$user_name = $user_data->user_nicename ? : '';
		$user_email = $user_data->user_email ? : '';
		$date_listed = $_REQUEST['get_date'] ? : '';
		$post_id = $_REQUEST['post_id'] ? : '';
		$current_listed_users = get_post_meta($post_id, 'listed_users', true) ? : array();
		$listed_user[] = array(
								'user_id' => $current_user_id, 
								'user_name' => $user_name,
								'user_email' => $user_email,
								'date_listed' => $date_listed 

		);
		$merge_lu = array_merge($current_listed_users, $listed_user);
		update_post_meta($post_id, 'listed_users', $merge_lu);
		die();

	}
	function bpl_view_booking_admin() {
		$clicked_date = $_REQUEST['clicked_date'] ? : '';
		$post_id = $_REQUEST['post_id'] ? : '';
		$listed_users = get_post_meta($post_id, 'listed_users', true) ? : array();
		$listed_on_this_date = array();
		$user_number = 1;
		foreach ($listed_users as $key => $value) {
			if ($value['date_listed'] == $clicked_date) {
				$listed_on_this_date[] = $value['user_name'];
			}
		}
		foreach ($listed_on_this_date as $key => $value) {
			echo '<p class="bpl-vi-list"><span class="bpl-popup_label">' . $user_number . '.)</span> ' . $value . '</p>';
			$user_number++;
		}
		die();
	}
	function bpl_cancel_booking() {
		$clicked_date = $_REQUEST['clicked_date'] ? : '';
		$post_id = $_REQUEST['post_id'] ? : '';
		$user_id = get_current_user_id();
		$current_listed_users = get_post_meta($post_id, 'listed_users', true) ? : array();
  		foreach($current_listed_users as $key => $value) {
			if ($value['user_id'] == $user_id && $value['date_listed'] == $clicked_date ) {
				unset($current_listed_users[$key]);
			}
		}
		update_post_meta($post_id, 'listed_users', $current_listed_users);
		die();
	}
	function bpl_register_settings_page() {
  		add_options_page('BookPostLight Settings', 'Book Post Light', 'manage_options', 'bplSettings', array(
                $this,
                'bpl_settings_page'
            ));
	}
	function bpl_settings_group() {
		register_setting( 'bpl_settings_group', 'bpl_user_book_can');
		register_setting( 'bpl_settings_group', 'bpl_num_users');
	}
	function bpl_settings_page() { 
		if (!current_user_can('manage_options')) :
			wp_die('You are not allowed here!');
		endif;
		$bpl_user_book_can = get_option('bpl_user_book_can') ? : 'subscriber';
		$bpl_num_users = get_option('bpl_num_users') ? : '10';
		$bubc_array = explode(',', $bpl_user_book_can); ?>
		<div class="wrap">
			<h1>Book post light settings</h1>
			<form method="post" action="options.php">
				<?php settings_fields( 'bpl_settings_group' ); ?>
				<table class="form-table" role="presentation">
				<tbody>
				<tr>
					<th scope="row"><label for="bpl_user_book_can">User role than can book</label></th>
					<td>
						<input name="bpl_user_book_can" type="text" id="bpl_user_book_can" value="<?php echo esc_attr($bpl_user_book_can); ?>" class="regular-text ltr" >
						<p class="description" id="bpl-user-book-can-description">Use commma(,) to seperate user slugs and no space please(i.e. subscriber,business-owner)</p>
					</td>
				</tr>
				<tr>
					<th scope="row"><label for="bpl_num_users">Number of users</label></th>
					<td>
						<input name="bpl_num_users" type="number" id="bpl_num_users" value="<?php echo esc_attr($bpl_num_users); ?>" class="regular-text ltr">
						<p class="description" id="bpl-user-book-can-description">Number of users that can book in a day.</p>
					</td>
				</tr>
				</tbody>
			</table>
			<p class="description" id="bpl-user-book-can-description"><strong>To display calendar paste shortcode [bpl_display_calendar] in your post.</strong></p>
			<?php submit_button(); ?>
			</form>
		</div>
	<?php
	}
}
new BOOK_POST_LIGHT_CLASS;





