<?php
global $post;
	$post_id = $post->ID;
	$now = new DateTime(); 
	$current_day = date('j');
	$current_month = date('m');
	$current_year = date('Y');
	//convert to month name
	$show_month = date("F", strtotime($current_year . "-".$current_month."-".$current_day));
	$show_year = date("Y", strtotime($current_year . "-".$current_month."-".$current_day));
if ( is_single() && 'post' == get_post_type() ) :
	?>
	<div class="bpl-calendar-wrap">
		<div class="bpl-calendar-nav" post-id="<?php echo $post_id; ?>">
			<span class="bpl-change-month back-today" action='current-month'>Back to today </span>
			<span class="bpl-change-month bpl-nav" action='prev-month'>< </span>
			<span class="bpl-change-month bpl-nav" action='next-month'> ></span>
		</div>
		<div class="bpl-main-calendar">
			<div class="bpl-date-getter">
				<div class="bpl-show-date" show-month="<?php echo $current_month; ?>" show-year="<?php echo $current_year; ?>"><?php echo $show_month . ' ' . $show_year; ?></div> 
				<?php echo bpl_draw_calendar($current_month, $current_year, $post_id); ?>
			</div>
		</div>
  <!-- Set Availability pop up -->
		<div class="bpl-sa-popup-main bpl-popups">
			<div class="bpl-popup-dialog">
				<div class="bpl-popup-content">
					<form id="bpl-sa-popup-form" class="bpl-popup-inner" method="GET">
						<p class="bpl-popup-title">Set availability</p>
            <p class="bpl-popup_label" >Date:</p>
  						<input type="text" class="bpl-sa-get-date bpl-get-date bpl-input-field"  post-id="<?php echo $post_id; ?>" value="" readonly>
              <div class="form-btns">
                <input  class="bpl-sa-submit bpl-submit bpl-btn" id="make_available" type="button" value="Submit">
  						  <input class="bpl-sa-cancel bpl-cancel bpl-btn" type="button" value="Cancel">
              </div>
					</form>
				</div>
			</div>
		</div>
  <!-- Book availabilty pop up -->
    <div class="bpl-ba-popup-main bpl-popups">
      <div class="bpl-popup-dialog">
        <div class="bpl-popup-content">
          <form id="bpl-ba-popup-form" class="bpl-popup-inner" method="GET">
            <p class="bpl-popup-title">Get listed</p>
            <p class="bpl-popup_label" >Date:</p>
            <input type="text" class="bpl-ba-get-date bpl-get-date bpl-input-field"  post-id="<?php echo $post_id; ?>" value="" readonly>
            <div class="form-btns">
              <input  class="bpl-ba-submit bpl-submit bpl-btn" id="make_available" type="button" value="Submit">
              <input class="bpl-ba-cancel bpl-cancel bpl-btn" type="button" value="Cancel">
            </div>
          </form>
        </div>
      </div>
    </div>
  <!-- View listed users pop up -->
    <div class="bpl-vlu-popup-main bpl-popups">
      <div class="bpl-popup-dialog">
          <div class="bpl-popup-content">
            <div id="bpl-vlu-wrap" class="bpl-popup-inner">
              <p class="bpl-popup-title">Listed</p>
              <p class="bpl-popup_label" >Date:</p>
              <input type="text" class="bpl-vlu-get-date bpl-get-date bpl-input-field"  post-id="<?php echo $post_id; ?>" value="" readonly>
              <p class="bpl-popup_label" >Listed users:</p>
              <div class="bpl-vlu-info">

              </div>
              <div class="form-btns">
                  <input class="bpl-vlu-cancel bpl-cancel bpl-btn" type="button" value="Cancel">
              </div>
            </div>
          </div>
      </div>
    </div>
  <!-- View listed users pop up -->
    <div class="bpl-login-popup-main bpl-popups">
      <div class="bpl-popup-dialog">
        <div class="bpl-popup-content">
          <div id="bpl-login-wrap" class="bpl-popup-inner">

            <p class="bpl-popup-title">Please login to get listed</p>
            <p class="bpl-popup_label" >If you don't have an account, please contact system administrator. Thank you!</p>
            <div class="form-btns">
                <a href="<?php echo wp_login_url(); ?>" class="bpl-login-submit bpl-submit bpl-btn">Login</a>
                <input class="bpl-login-cancel bpl-cancel bpl-btn" type="button" value="Cancel">
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
<?php   
else :
  echo '<a href="'. get_post_permalink($post_id) . '">Go to post page</a>';
endif; ?>


