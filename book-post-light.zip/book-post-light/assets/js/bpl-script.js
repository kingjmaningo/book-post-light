jQuery(document).ready(function($){
	// Change month
	$('.bpl-change-month').click(function() { 
		var month_action = $(this).attr('action');
		var show_month = $('.bpl-show-date').attr('show-month');
		var show_year = $('.bpl-show-date').attr('show-year');
		var post_id = $('.bpl-calendar-nav').attr('post-id');
		$.ajax({
	      url : bpl_ajax_object.ajaxurl,
	      type : 'post',
	      data : {
	        action : 'bpl_move_month',
	       	show_month : show_month,
	       	show_year : show_year,
	       	month_action : month_action,
	       	post_id : post_id
	      },
	      	beforeSend: function(){
	      		$('.bpl-calendar-wrap').addClass('calendar-loading');
	      	},
	        success: function(response){
	        	$('.bpl-calendar-wrap').removeClass('calendar-loading');
	            $('.bpl-main-calendar').html(response);
	        }
	    });
	});
	// remove availability
	$('.bpl-calendar-wrap').delegate('.calendar-day.admin.available', 'click', function(){
		var remove_availability = $(this).find('.day-number').attr('data-date');
		var post_id = $('.bpl-calendar-nav').attr('post-id');
		var confirmation = confirm("Are you sure you want to remove?");
		if (confirmation == true) {
			$.ajax({
				url : bpl_ajax_object.ajaxurl,
				type : 'post',
				data : {
					action : 'bpl_remove_avaibility',
					remove_availability : remove_availability,
					post_id : post_id
				},
				beforeSend: function(){
					$('.bpl-calendar-wrap').addClass('calendar-loading');
      			},
       			success: function(response){
        			$('.bpl-calendar-wrap').removeClass('calendar-loading');
					location.reload();
				}
		    });
		}
	});
	// Check listed
	$('.bpl-calendar-wrap').delegate('.calendar-day.admin.booked', 'click', function() {
		var clicked_date = $(this).find('.day-number').attr('data-date');
		var post_id = $('.bpl-calendar-nav').attr('post-id');
		$.ajax({
				url : bpl_ajax_object.ajaxurl,
				type : 'post',
				data : {
				action : 'bpl_view_booking_admin',
					clicked_date : clicked_date,
					post_id : post_id
				},
				beforeSend: function(){
					$('.bpl-vlu-info').html('<div class="bpl-loader"><div></div><div></div><div></div><div></div></div>');
				},
				success: function(response){
					$('.bpl-vlu-info').html(response);
					
				}
		    });
	});
	// Cancel booking
	$('.bpl-calendar-wrap').delegate('.calendar-day.customer.booked', 'click', function(){
		var clicked_date = $(this).find('.day-number').attr('data-date');
		var post_id = $('.bpl-calendar-nav').attr('post-id');
		var confirmation = confirm("Are you sure you want to cancel your booking?");
		if (confirmation == true) {
			$.ajax({
				url : bpl_ajax_object.ajaxurl,
				type : 'post',
				data : {
				action : 'bpl_cancel_booking',
					clicked_date : clicked_date,
					post_id : post_id
				},
				beforeSend: function(){
					$('.bpl-calendar-wrap').addClass('calendar-loading');
      			},
       			success: function(response){
        			$('.bpl-calendar-wrap').removeClass('calendar-loading');
					location.reload();
				}
		    });
		}
	});

	$('.bpl-calendar-wrap').delegate('.calendar-day.available.full', 'click', function(e){
		return false;
	});

	// Show Popup
	$('.bpl-calendar-wrap').delegate('.calendar-day', 'click', function(){
		var clicked_date = $(this).find('.day-number').attr('data-date');
		var post_id = $('.bpl-calendar-nav').attr('post-id');
		if ($(this).hasClass('admin') && $(this).hasClass('unavailable') && $(this).hasClass('active')) {
			$('.bpl-sa-popup-main').css('display','table');
			$('.bpl-sa-get-date').attr('value', clicked_date);
		} else if ($(this).hasClass('available') && $(this).hasClass('active') && $(this).hasClass('customer')) {
			if(!$(this).hasClass('full')) {
				$('.bpl-ba-popup-main').css('display','table');
				$('.bpl-ba-get-date').attr('value', clicked_date);
			}
		} else if ($(this).hasClass('admin') && $(this).hasClass('booked')) {
			$('.bpl-vlu-popup-main').css('display','table');
			$('.bpl-vlu-get-date').attr('value', clicked_date);
		} else if ($(this).hasClass('available') && $(this).hasClass('visitor')) {
			$('.bpl-login-popup-main').css('display','table');
		}
	});
	// Close Popup
	$('.bpl-cancel').click(function() {
		$('.bpl-popups').css('display','none');
	});
	// Submit availability
	$('.bpl-sa-popup-main').delegate('.bpl-sa-submit', 'click', function(){
		var post_id = $('.bpl-sa-get-date').attr('post-id');
		var get_date = $('.bpl-sa-get-date').val();
		$.ajax({
			url : bpl_ajax_object.ajaxurl,
			type : 'post',
			data : {
				action : 'bpl_set_availability',
				get_date : get_date,
				post_id : post_id,
			},
			beforeSend: function(){
				$('.form-btns').html('<div class="bpl-loader"><div></div><div></div><div></div><div></div></div>');
			},
			success: function(response){
				location.reload();
			}
		});
	});
	// Get listed
	$('.bpl-ba-popup-main').delegate('.bpl-ba-submit', 'click', function(){
		var post_id = $('.bpl-ba-get-date').attr('post-id');
		var get_date = $('.bpl-ba-get-date').val();
		$.ajax({
			url : bpl_ajax_object.ajaxurl,
			type : 'post',
			data : {
				action : 'bpl_get_listed',
				get_date : get_date,
				post_id : post_id,
			},
			beforeSend: function(){
			$('.form-btns').html('<div class="bpl-loader"><div></div><div></div><div></div><div></div></div>');
			},
			success: function(response){
				location.reload();
			}
		});
	});
});







