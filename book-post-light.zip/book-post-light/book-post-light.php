<?php
/*
  Plugin Name: Book post light
  Plugin URI: #
  Description: Create booking for an appointment using this simple post booking plugin.
  Version: 1.0
  Author: Kingj Maningo
  Author URI: http://facebook.com/jman0709
  Text Domain: book-post-lignt
*/
 if ( ! defined( 'ABSPATH' ) ){ exit; }
define( 'BOOK_POST_LIGHT_PLUGIN_URL', plugin_dir_url( __FILE__ ) );
define( 'BOOK_POST_LIGHT_PLUGIN_PATH', plugin_dir_path( __FILE__ ) );
define( 'BOOK_POST_LIGHT_TEXTDOMAIN', 'book-post-lignt' );
define( 'BOOK_POST_LIGHT_VERSION', '1.0.0' );
define( 'BOOK_POST_LIGHT_DB_VERSION', '1.0.0' );
define( 'BOOK_POST_LIGHT_HOME_URL', home_url() );
require_once( BOOK_POST_LIGHT_PLUGIN_PATH . 'admin/classes/class-core.php' );
require_once( BOOK_POST_LIGHT_PLUGIN_PATH . 'admin/includes/functions.php');